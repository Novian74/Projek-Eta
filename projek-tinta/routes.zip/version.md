// Laravel Framework 10.12.0
// Server          : 127.0.0.1 via TCP/IP
// Server version  : 10.4.24-MariaDB
// Server type     : MariaDB
// Visual Studio Code v1.79.2
// Server running on [http://127.0.0.1:8000]